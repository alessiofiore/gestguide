package it.mdps.gestguide.ui.vaadin.components;

import it.mdps.gestguide.common.StaticValues;
import it.mdps.gestguide.core.beans.CustomerBean;
import it.mdps.gestguide.core.beans.SchoolBean;
import it.mdps.gestguide.ui.services.UIFacade;

import java.util.List;

import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup.CommitEvent;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.data.fieldgroup.FieldGroup.CommitHandler;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.VerticalLayout;

public class AddCustomerComponent extends CustomComponent {
	
	private static final long serialVersionUID = 1L;
	
	private UIFacade uiFacade;

	private VerticalLayout verticalLayout = new VerticalLayout();
	private CustomerFormLayout formLayout = new CustomerFormLayout();
	private BeanFieldGroup<CustomerBean> formFieldGroup;
	
	private Button cancelButton = new Button(StaticValues.BUTTON_CANCEL);
	private Button saveButton = new Button(StaticValues.BUTTON_SAVE);
	
	public AddCustomerComponent(UIFacade uiFacade) {
		this.uiFacade = uiFacade;
		initLayout();
		initForm();
		initButtons();
	}
	
	public void initLayout() {
		setCompositionRoot(verticalLayout);
		
		verticalLayout.setSizeFull();
		verticalLayout.addComponent(new Label("Aggiungi cliente"));
		verticalLayout.addComponent(formLayout);		
		
		HorizontalLayout bottomLeftLayout = new HorizontalLayout();
		verticalLayout.addComponent(bottomLeftLayout);
		bottomLeftLayout.addComponent(saveButton);
		bottomLeftLayout.addComponent(cancelButton);
	}
	
	public void initForm() {
		formFieldGroup = formLayout.getBeanFieldGroup();
		formFieldGroup.addCommitHandler(new AddCommitHandler());
		
		ComboBox schoolSelect =  new ComboBox(StaticValues.LABEL_SCHOOL);
		schoolSelect.setInputPrompt(StaticValues.PROMP_SELECT_SCHOOL);
		schoolSelect.setNullSelectionAllowed(false);
		
		List<SchoolBean> schools = uiFacade.getSchools();
		for(SchoolBean s: schools) {
			schoolSelect.addItem(s.getNomeSede());
		}
		
		formLayout.addComponent(schoolSelect);
	}
	
	@SuppressWarnings("serial")
	private void initButtons() {
		saveButton.addClickListener(new ClickListener() {			
			@Override
			public void buttonClick(ClickEvent event) {
				try {
					formFieldGroup.commit();
				} catch (CommitException e) {
					Notification.show("KO!");
				}
			}
		});
		
		cancelButton.addClickListener(new ClickListener() {			
			@Override
			public void buttonClick(ClickEvent event) {
				setCompositionRoot(new CustomerComponent(uiFacade));
			}
		});
	}
	
	/* 
	 * ----------------------------------------------------------------------------
	 * BeanFieldGroup commit handler
	 * ----------------------------------------------------------------------------
	 */
	
	@SuppressWarnings("serial")
	private class AddCommitHandler implements CommitHandler {

		@Override
		public void preCommit(CommitEvent commitEvent) throws CommitException {
			
		}

		@SuppressWarnings("unchecked")
		@Override
		public void postCommit(CommitEvent commitEvent) throws CommitException {			
			CustomerBean bean = ((BeanFieldGroup<CustomerBean>) commitEvent.getFieldBinder()).getItemDataSource().getBean();
//			uiFacade.addCustomer(bean);
			Notification.show(bean.getFirstName() + "aggiunto");			
		}

	}

	/* ---------------------------------------------------------------------------- */

}
