package it.mdps.gestguide.ui.vaadin.components;

import it.mdps.gestguide.common.StaticValues;
import it.mdps.gestguide.core.beans.CustomerBean;

import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.TextField;

public class CustomerFormLayout extends FormLayout {
	
	private static final long serialVersionUID = 1L;

	protected BeanFieldGroup<CustomerBean> beanFieldGroup = new BeanFieldGroup<CustomerBean>(CustomerBean.class);
	
	private TextField firstName = new TextField(StaticValues.NOME);
	private TextField lastName = new TextField(StaticValues.COGNOME);
	private TextField socialSecurityNumber = new TextField(StaticValues.CODICE_FISCALE);
	private DateField dateOfBirth = new DateField(StaticValues.DATA_NASCITA);
	private TextField address = new TextField(StaticValues.INDIRIZZO);
	private TextField city = new TextField(StaticValues.CITTA);
	private TextField province = new TextField(StaticValues.PROVINCIA);	
	private TextField zipCode = new TextField(StaticValues.CAP);
	private TextField phone = new TextField(StaticValues.TELEFONO);
	private TextField mobilePhone = new TextField(StaticValues.CELLULARE);
	private TextField email = new TextField(StaticValues.EMAIL);
	
	public CustomerFormLayout() {
		setSpacing(true);
		
		// bind fields to bean attributes
		beanFieldGroup.bind(firstName, "firstName");
		beanFieldGroup.bind(lastName, "lastName");
		beanFieldGroup.bind(address, "address");
		beanFieldGroup.bind(socialSecurityNumber, "socialSecurityNumber");
		beanFieldGroup.bind(dateOfBirth, "dateOfBirth");
		beanFieldGroup.bind(city, "city");
		beanFieldGroup.bind(province, "province");
		beanFieldGroup.bind(zipCode, "zipCode");
		beanFieldGroup.bind(phone, "phone");
		beanFieldGroup.bind(mobilePhone, "mobilePhone");
		beanFieldGroup.bind(email, "email");

		// Buffer the form content
		beanFieldGroup.setBuffered(true);
		
		//TODO Customize bean size
		
		// Add the fields
		addComponent(firstName);
		addComponent(lastName);
		addComponent(socialSecurityNumber);
		addComponent(dateOfBirth);
		addComponent(address);
		addComponent(city);
		addComponent(province);
		addComponent(zipCode);
		addComponent(phone);
		addComponent(mobilePhone);
		addComponent(email);
		
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.COGNOME, "lastName"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.CODICE_FISCALE, "socialSecurityNumber"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.DATA_NASCITA, "dateOfBirth", DateField.class));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.INDIRIZZO, "address"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.CITTA, "city"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.PROVINCIA, "province"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.CAP, "zipCode"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.TELEFONO, "phone"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.CELLULARE, "mobilePhone"));
//		addComponent(beanFieldGroup.buildAndBind(StaticValues.EMAIL, "email"));
		
	}
	
	public BeanFieldGroup<CustomerBean> getBeanFieldGroup() {
		return beanFieldGroup;
	}
}
