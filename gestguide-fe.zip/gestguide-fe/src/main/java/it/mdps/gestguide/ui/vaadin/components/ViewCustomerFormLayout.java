package it.mdps.gestguide.ui.vaadin.components;

import it.mdps.gestguide.common.StaticValues;

public class ViewCustomerFormLayout extends CustomerFormLayout {

	private static final long serialVersionUID = 1L;

	public ViewCustomerFormLayout() {
		addComponent(super.beanFieldGroup.buildAndBind(StaticValues.AUTOSCUOLA, "school"));
	}
}
